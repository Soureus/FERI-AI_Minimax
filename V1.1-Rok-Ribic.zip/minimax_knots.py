from Knots_Game import Game

game = Game()